import chess

class MinimaxAI():
    def __init__(self, depth):
        pass

    def choose_move(self, board):
        pass
